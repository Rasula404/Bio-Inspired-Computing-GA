# Name: Team 19 Wild Fire Model
# Dimensions: 2
# --- Set up executable path, do not edit ---
import sys
import inspect
this_file_loc = (inspect.stack()[0][1])
main_dir_loc = this_file_loc[:this_file_loc.index('ca_descriptions')]
sys.path.append(main_dir_loc)
sys.path.append(main_dir_loc + 'capyle')
sys.path.append(main_dir_loc + 'capyle/ca')
sys.path.append(main_dir_loc + 'capyle/guicomponents')
# ---

from capyle.ca import Grid2D, Neighbourhood, CAConfig, randomise2d
import capyle.utils as utils
import numpy as np 
import math

#CONSTANTS

#fire propagation values for different terrains and the initial 
#probability P_H
# Dictionary for pveg values
#adapted by using information from the article "1-s2.0-S0577907320300873-main.pdf" 
P_H = 0.58
PVEG_VALS = {
    'chaparral': 0.4,
    'lake': -1,
    'canyon': 0.4,
    'forest': 0.4,
    'town' : 1
}

# Dictionary for pdens values
PDEN_VALS = {
    'chaparral': 0.3,
    'lake': -1,
    'canyon': 0.3,
    'forest': 0.3,
    'town' : 0
}
V = 1.0   # wind velocity
#constants used in "nhess-19-169-2019.pdf" for calculating 
#wind effect
C_1 = 0.045
C_2 = 0.131

WIND_DIR = 'N'  # wind direction
# COSINES: Dictionary of precomputed cosine values for wind directions
# --------------------------------------------------------------
# The COS_VALS dictionary associates wind directions with lists of cosine
# values. These cosine values are used in the simulation to model the impact
# of wind on the spread of the wildfire. Each wind direction has an associated
# list of cosine values representing the cosine of angles between the wind
# direction and neighboring directions in a 2D grid.
COSINES = {'NW': [1.0, 0.707107, 0, 0.707107, -0.707107, 0, -0.707107, -1.0],
            'N': [0.707107, 1.0, 0.707107, 0, 0, -0.707107, -1.0, -0.707107],
            'NE': [0, 0.707107, 1.0, -0.707107, 0.707107, -1.0, -0.707107, 0],
            'W': [0.707107, 0, -0.707107, 1.0, -1.0, 0.707107, 0, -0.707107],
            'E': [-0.707107, 0, 0.707107, -1.0, 1.0, -0.707107, 0, 0.707107],
            'SW': [0, -0.707107, -1.0, 0.707107, -0.707107, 1.0, 0.707107, 0],
            'S': [-0.707107, -1.0, -0.707107, 0, 0, 0.707107, 1.0, 0.707107],
            'SE': [-1.0, -0.707107, 0, -0.707107, 0.707107, 0, 0.707107, 1.0]
            }


def setup(args):
    config_path=args[0]
    config=utils.load(config_path)
    # ---THE CA MUST BE RELOADED IN THE GUI IF ANY OF THE BELOW ARE CHANGED---
    config.title="Wildfire Simulator"
    config.dimensions=2
    config.states=(0, 1, 2, 3, 4, 5, 6)
    config.grid_dims=(400, 400)

    grid=np.genfromtxt('map_grid.txt', delimiter=',')
    grid=np.repeat(grid, 10, axis=0)
    grid=np.repeat(grid, 10, axis=1)

    config.initial_grid=grid

# ------------------------------------------------------------------------


# ---- Override the defaults below (these may be changed at anytime) ----
    colors = {
    "chaparral": (0.6, 0.8, 0.2),   # Light Green
    "canyon": (1.0, 1.0, 0.0),      # Yellow
    "forest": (0.0, 0.3, 0.0),      # Dark Green
    "lake": (0.0, 0.0, 1.0),        # Blue       
    "town": (0.4, 0.2, 0.0),        # Brown
    "burning": (1.0, 0.0, 0.0),     # Red
    "burned": (0.0, 0.0, 0.0)       # Black
   }

    config.state_colors=list(colors.values())
    config.wrap=False
    #config.num_generations = 1
    #config.grid_dims = (100, 100)

   # ----------------------------------------------------------------------

    if len(args) == 2:
        config.save()
        sys.exit()

    return config

def is_town_reached(grid):
    # Define the region corresponding to the town in the grid
    town_region = grid[250:270, 150:170] #not sure whether correct coords...

    # Check if any cell in the town region has a state equal to 5 (burning)
    return np.any(town_region == 5)

def transition_func(grid, neighbourstates, neighbourcounts, fuel_grid, reached_town,counter):

    # terrain types:
    # 0 - chaparral
    # 1 - canyon
    # 2 - forest
    # 3 - lake
    # 4 - town
    # other:
    # 5 - burning
    # 6 - dead

    counter += 1
    # if a cell is burning (state 5), it will be completely burned down (state 6)
    # after number of steps equal to the amount of fuel for the cell.
    burning_cells = (grid == 5)
    fuel_grid[burning_cells] -= 1



    # set up grid with base burn probabilities for each cell
    ignite_prob_grid = setup_ignite_probabilities(grid)

    # create a new grid for the wind effect
    wind_prob_grid = np.zeros(grid.shape)

    #for each direction calculate ignition propability dependant on wind direction
    for (direction, cos_a) in zip(neighbourstates, COSINES[WIND_DIR]):
        curr_burning_direction = (direction == 5)

        # update wind probability grid
        # P_W = exp[V(c1 + c2(cos(a) - 1))] 
        #formula taken from "nhess-19-169-2019.pdf"
        # where a is angle between wind direction and current burning direction
        wind_prob_grid[curr_burning_direction] += math.exp( V*(C_1 + C_2*(cos_a - 1)))

    
    # Note: if a cell doesn't have any burning neighbours, then
    # it will have value zero in wind_prob_grid, so it will also zero its
    # value in ignite_prob_grid after the multiplication below, so we don't
    # multiply base burn probabilities by summed P_W from each direction
    ignite_prob_grid *= wind_prob_grid

    # generate random numbers to introduce stochasticity in ignition process
    # --------------------------------------------------------------
    # Explanation:
    # The random_grid is used to simulate the inherent randomness in the ignition process of a wildfire.
    # Each cell's ignition probability is compared with a random value, and if the random value is lower,
    # the cell is marked for ignition. This introduces a level of uncertainty and variability in the
    # simulation, capturing the stochastic nature of real-world wildfire spread.
    # --------------------------------------------------------------
    random_grid = np.random.rand(*grid.shape)

    #identify cells to ignite
    cells_to_ignite = random_grid < ignite_prob_grid
    #set those cells to burning state
    grid[cells_to_ignite] = 5

    #identify cells which ran out of fuel
    dead_cells = (fuel_grid == 0)
    #set them to dead state
    grid[dead_cells] = 6

    #check if we reached the town
    if not np.any(reached_town): #check if fire reached the town
        reached_town[0] = is_town_reached(grid)
        if np.any(reached_town):
            print(int(counter[0])) #print the time stamp


    return grid

#The function to assign fuel parameter to a cell depending
#on the type of terrain it is representing. 
#This function necessarily provides a healthspan for
#every terrain while controlling the burning capacity as well  
#by the availability of fuel.
def construct_fuel_parameters(grid):

    fuel_grid=np.zeros(grid.shape)
    
    #assign fuel parameter depending on the variety of 
    #the cell according to the terrain.
    #final values were determined after testing with various values
    # terrain types:
    # 0 - chaparral
    # 1 - canyon
    # 2 - forest
    # 3 - lake
    # 4 - town
    chap=(grid == 0)
    fuel_grid[chap]=30 #fairly inflammable low level vegetation

    canyon=(grid == 1)
    fuel_grid[canyon]=3 #highly inflammable small density

    forest=(grid == 2)
    fuel_grid[forest]=120 #slowly burning denes vegetation

    lake=(grid == 3)
    #no inflammability 
    #can't be zero because zero fuel means it's burned down
    fuel_grid[lake]=-1 

    town=(grid == 4)
    fuel_grid[town]=5 # Assumed that town is highly inflammable
   
    return fuel_grid

def setup_ignite_probabilities(grid):
    #the probabilities of each terrain was calculated
    #using the formula = P_H*(1+PVEG)*(1+PDEN)
    # the formula is taken by the article "1-s2.0-S0577907320300873-main.pdf"
    ignite_grid=np.zeros(grid.shape)
    chap=(grid == 0)
    ignite_grid[chap]= (1+PVEG_VALS['chaparral']) *(1+PDEN_VALS['chaparral'])

    canyon=(grid == 1)
    ignite_grid[canyon]= (1+PVEG_VALS['canyon']) *(1+PDEN_VALS['canyon'])

    forest=(grid == 2)
    ignite_grid[forest]=(1+PVEG_VALS['forest']) *(1+PDEN_VALS['forest'])

    lake=(grid == 3)
    ignite_grid[lake]=(1+PVEG_VALS['lake']) *(1+PDEN_VALS['lake'])

    town=(grid == 4)
    ignite_grid[town]=(1+PVEG_VALS['town']) *(1+PDEN_VALS['town'])

    #multiply by initial probability and
    #scalar factor of 0.2 to even the spread
    ignite_grid *= P_H*0.2
    return ignite_grid


def main():
    # Open the config object
    config=setup(sys.argv[1:])
    # Create fuel numpy array
    fuel_grid=construct_fuel_parameters(config.initial_grid)
    config.num_generations = 1000
    # Set initial burning cell
    # fire start location (top right corner)
    # assume that it starts from the incinerator
    config.initial_grid[0][-1]=5  

    # Create grid object
    reached_town = np.array([False])
    counter = np.array([0])
    grid=Grid2D(config, (transition_func, fuel_grid, reached_town,counter))

    # Run the CA, save grid state every generation to timeline
    timeline=grid.run()

    # save updated config to file
    config.save()
    # save timeline to file
    utils.save(timeline, config.timeline_path)


if __name__ == "__main__":
    main()
